var json_BogorLokasiRencanaLogger_2 = {
"type": "FeatureCollection",
"name": "BogorLokasiRencanaLogger_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Jalur Distribusi depan Kawasaki Tajur", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.825304717832907, -6.632382014335275, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "DMA Perumda Cipaku", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.814526657472896, -6.635222809547862, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "Jalur Distribusi Jembatan Laladon Bubulak", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.754958225431906, -6.576418761533347, 0.0 ] } }
]
}
