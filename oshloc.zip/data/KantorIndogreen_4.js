var json_KantorIndogreen_4 = {
"type": "FeatureCollection",
"name": "KantorIndogreen_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null, "Ket": "Indogreen Office" }, "geometry": { "type": "Point", "coordinates": [ 106.765564324750912, -6.561321250498207 ] } }
]
}
