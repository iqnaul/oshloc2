var json_PDAMUTM_7 = {
"type": "FeatureCollection",
"name": "PDAMUTM_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null, "PDAM": "Tirta Patriot Kota Bekasi" }, "geometry": { "type": "Point", "coordinates": [ 107.001399303852622, -6.229810883634295 ] } },
{ "type": "Feature", "properties": { "id": null, "PDAM": "PDAM Tirta Asasta Kota Depok" }, "geometry": { "type": "Point", "coordinates": [ 106.833433452829198, -6.395368162933835 ] } },
{ "type": "Feature", "properties": { "id": null, "PDAM": "PDAM Tirta Pakuan Kota Bogor" }, "geometry": { "type": "Point", "coordinates": [ 106.815413354393883, -6.620168421300886 ] } }
]
}
