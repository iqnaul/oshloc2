var json_Bekasititik_Lokasi_OSH_2019Point_6 = {
"type": "FeatureCollection",
"name": "Bekasititik_Lokasi_OSH_2019Point_6",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Rumah Pak Syafrin", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 107.020034634609999, -6.197774146067478, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "Permata Hijau", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 107.004223059393695, -6.203286111111112, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "Summarecon", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.994922526922096, -6.231338252920526, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "PDAM Bekasi", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 107.001236214395604, -6.230359209878532, 0.0 ] } }
]
}
