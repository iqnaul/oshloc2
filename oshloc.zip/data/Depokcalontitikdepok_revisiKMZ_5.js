var json_Depokcalontitikdepok_revisiKMZ_5 = {
"type": "FeatureCollection",
"name": "Depokcalontitikdepok_revisiKMZ_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "PDAM Wilayah Timur", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.851588, -6.395392, 0.0 ] } },
{ "type": "Feature", "properties": { "Name": "Taman Duta", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.851546, -6.372479, 0.0 ] } }
]
}
