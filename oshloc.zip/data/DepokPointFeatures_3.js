var json_DepokPointFeatures_3 = {
"type": "FeatureCollection",
"name": "DepokPointFeatures_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Pump Booster Sukatani", "description": null, "timestamp": null, "begin": null, "end": null, "altitudeMode": null, "tessellate": -1.0, "extrude": 0.0, "visibility": -1.0, "drawOrder": null, "icon": null }, "geometry": { "type": "Point", "coordinates": [ 106.874634, -6.386553, 0.0 ] } }
]
}
